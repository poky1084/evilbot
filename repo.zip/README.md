# evilbot
stake.com, stake.us, primedice bot by me with ❤

a javascript coded bot for Stake, Primedice<br />
the strategy script must be coded in javascript (JsMode), or can run Lua script too. (LuaMode)

# Videos: <br />]
install extension: [https://vimeo.com/1092943750](https://vimeo.com/1092943750) <br />
demo: https://www.youtube.com/watch?v=9io2MuZwfCY
# Info: <br />
Please give a Star on the repo in case you liked/used it. Thank you!

<b>Donate1:</b> https://cwallet.com/t/87SPDPGG <br />
<b>Donate2:</b> https://ko-fi.com/poky <br />

<b>Discord</b>: fisk_992 <br />
<b>Telegram:</b>: https://t.me/poky_1084


sourcecode: https://gitlab.com/poky1084/evilbot


<img width="1123" height="676" alt="Screenshot 2026-01-16 110728" src="https://github.com/user-attachments/assets/4eef67cb-d36a-428c-ba40-f66edc219ad6" />

# Use: <br />

<b>functions:</b> `resetseed('clientseed'), resetstats(), vault(amount), unvault(amount, 'password'), log('text'), view(bet.id), start(), stop(), sleep(1000), resetAll(), resetChart(), deleteLogs()` <br />

<b>Variables:</b> `game = "limbo", win, currentstreak, profit, wagered, balance, previousbet, currentprofit, bets, wins, losses, losestreak, winstreak, fastmode = true` <br />
<b>lastBet vars:</b> `lastBet.Roll, lastBet.win, lastBet.amount, lastBet.payout, lastBet.payoutMultiplier, lastBet.name, lastBet.id`

Use `bet.*` variable to access betting data. eg: `bet.payoutMultiplier` or `bet.crash?.event?.multiplier` or `bet.slide?.event?.status`

<b>Play sound effect on hit, use:</b> `ding()` or `beep()`

<b>Crash game manual cashout:</b> `cashout()` in script, or use it as command in Log tab

!!the strategy must be in `dobet()` method, and `dobet()` must be declared as shown below!!

```javascript
nextbet = 0.00001 //in crypto format, not USD

dobet = function(){
 //strategy code
}

# or:

function dobet(){
 //strategy code
}
```

**primedice X:**

```javascript
game = "primedice"
condition = "rollOutside"  // use these: "rollBetween" or "rollBetweenTwo" or "rollOutside"
target1 = 5
target2 = 24
target3 = 45
target4 = 68
nextbet = 0
```

**Blackjack:**

```javascript
game = "blackjack"
nextbet=0
basebet=nextbet
nextAction = "BLACKJACK_STAND" // can be these: "BLACKJACK_DOUBLE" or "BLACKJACK_HIT" or "BLACKJACK_SPLIT" or "BLACKJACK_INSURANCE" or "BLACKJACK_NOINSURANCE"

function dobet() {
  if(win){
      nextbet = basebet
  }
}

function round(){

  if (currentBet.state.dealer[0].value === 11){
    	nextAction = "BLACKJACK_NOINSURANCE"
  } else {
    	nextAction = "BLACKJACK_STAND"
  }
  if (currentBet.state.player[0].actions.includes("insurance") || currentBet.state.player[0].actions.includes("noInsurance")) {
  	 	nextAction = "BLACKJACK_STAND"
  }
  return nextAction
}
```

**video poker: #1**

```javascript
game = "videopoker"
nextbet = 0.0
target = null
hunt1 = ["2", "2", "2", "K", "K"];
hunt2 = ["2", "2", "K", "K", "K"];

function dobet() {
    const currentHand = bet.state.playerHand.map(card => card.rank);

    const isHit = [...new Set(hunt1)].every(r =>
        currentHand.filter(card => card === r).length === hunt1.filter(card => card === r).length
    );

    const isHit2 = [...new Set(hunt2)].every(r =>
        currentHand.filter(card => card === r).length === hunt2.filter(card => card === r).length
    );

    if (isHit) {
		stop();
		beep();
    }

    if (isHit2) {
		stop();
		beep();
    }
}
```

**video poker: #2**

```javascript
game = "videopoker"
nextbet = 0.0
target = null
hunting = [
  { 10: 2, A: 3 },
  { 10: 3, A: 2 }
]
// what pattern to hunt, it stops if these cards hit the player hand

function dobet() {

  const finalHand  = bet.state.playerHand;
  const hitLabel = checkTargetHit(finalHand, hunting);
	if (hitLabel) {
		stop();
		beep();
	}
}
```

**video poker: #3**

```javascript
game = "videopoker"
nextbet = 0.0
target = [
  { A: 2, K: 3 },
  { A: 3, K: 2 }
]
// target = null
// set this if want to run overall optimal strategy,
// or fill card labels and how many to find { card: amount, Q: 3 }

function dobet() {

  const finalHand  = bet.state.playerHand;
  const hitLabel = checkTargetHit(finalHand, target);
	if (hitLabel) {
		stop();
		beep();
	}

  if(bet.payoutMultiplier >= 799){
	stop();
	beep();
  }

  const handresult = bet.state.handResult;
  if(handresult == "fourOfAKind"){
    stop();
    beep();
  }
}

// Possible values:
//   "royalFlush"     → 800x
//   "straightFlush"  → 60x
//   "fourOfAKind"    → 22x
//   "fullHouse"      → 9x
//   "flush"          → 6x
//   "straight"       → 4x
//   "threeOfAKind"   → 3x
//   "twoPair"        → 2x
//   "onePair"  → 1x
```

**moles:**

```javascript
game = "moles"
nextbet = 0
moles = 6
picks = [0,1,1,1,2,6]
```

**drill:**

```javascript
game = "drill"
nextbet = 0
target = 2
pick = 1
```

**Tarot:**

```javascript
game = "tarot"
difficulty = "medium"
nextbet = 0
```

**Chicken:**

```javascript
game = "chicken"
steps = 1
difficulty = "medium"
nextbet = 0
```

**Packs:**

```javascript
game = "packs"
nextbet = 0
```

**Bars:**

```javascript
game = "bars"
difficulty = "easy"
tiles = [2,3,4,5,6]
nextbet = 0
```

**Plinko:**

```javascript
game = "plinko"
rows = 8
risk = "low"
nextbet = 0
```

**Keno:**

```javascript
game = "keno"
numbers = [1,2,3,4,5,6,7,8]
risk = "low"
nextbet = 0
```

**Mines:**

```javascript
game = "mines"
fields = [1,2,3,4,5,6,7,8]
mines = 3
nextbet = 0
```

**Limbo:**

```javascript
game = "limbo"
target = 2
nextbet = 0
```

**Dice:**

```javascript
game = "dice"
chance = 49.5
nextbet = 0
bethigh = false
```

**Wheel:**

```javascript
game = "wheel"
nextbet = 0
risk = "low"
segments = 10
```

**baccarat:**

```javascript
game = "baccarat"
nextbet = { player: 0, banker: 0.004, tie: 0}
```

**dragon tower:**

```javascript
game = "dragontower"
nextbet = 0
difficulty = "easy"
eggs = [0,1]
```

**Roulette:**

```javascript
game = "roulette"
chips = [{"value": "number0", "amount": 0.001},{"value": "colorBlack", "amount": 0.001}]
```

Use this values, and put them in the chips variable:

```lua
ranges = {{value = "range2536",amount = 0.0001},{value = "range1324",amount = 0.0001},{value = "range0112",amount = 0.0001},{value = "range0118",amount = 0.0001},{value = "range1936",amount = 0.0001}}
parities = {{value = "parityOdd",amount = 0.0001},{value = "parityEven",amount = 0.0001}}
colors = {{value = "colorRed",amount = 0.0001},{value = "colorBlack",amount = 0.0001}}
rows = {{value = "row3",amount = 0.0001},{value = "row2",amount = 0.0001},{value = "row1",amount = 0.0001}}
numbers = {{value = "number0",amount = 0.0001},{value = "number1",amount = 0.0001},{value = "number2",amount = 0.0001}}
```

**flip:**

```javascript
game = "flip"
nextbet = 0
guesses = ["tails", "heads"]
```

**rock, paper, scissors:**

```javascript
game = "rps"
guesses = ["rock", "paper", "scissors"]
nextbet = 0
```

**pump:**

```javascript
game = "pump"
difficulty = "easy"
pumps = 1
nextbet = 0
```

**snakes:**

```javascript
game = "snakes"
difficulty = "easy"
rolls = 1
nextbet = 0
```

**cases:**

```javascript
game = "cases"
difficulty = "easy"
nextbet = 0
```

**darts:**

```javascript
game = "darts"
difficulty = "easy"
nextbet = 0
```

**diamonds:**

```javascript
game = "diamonds"
nextbet = 0
```

**bluesamurai:**

```javascript
game = "bluesamurai"
nextbet = 0
```

**scarabspin:**

```javascript
game = "scarabspin"
lines = 1
nextbet = 0
```

**tomeoflife:**

```javascript
game = "tomeoflife"
lines = 1
nextbet = 0
```

**Crash:**

```javascript
game = "crash"
target = 2
nextbet = 0

function dobet(){

}

function progress(){

	bet.crash?.event?.nextRoundIn !== undefined && bet.crash?.event?.nextRoundIn !== null ?  log(bet.crash?.event?.nextRoundIn) : true
	bet.crash?.event?.status !== undefined && bet.crash?.event?.status !== null ?  log(bet.crash?.event?.status) : true
	bet.crash?.event?.multiplier !== undefined && bet.crash?.event?.multiplier !== null ?  log(bet.crash?.event?.multiplier) : true

	bet.slide?.event?.nextRoundIn !== undefined && bet.slide?.event?.nextRoundIn !== null ?  log(bet.slide?.event?.nextRoundIn) : true
	bet.slide?.event?.status !== undefined && bet.slide?.event?.status !== null ?  log(bet.slide?.event?.status) : true
	bet.slide?.event?.multiplier !== undefined && bet.slide?.event?.multiplier !== null ?  log(bet.slide?.event?.multiplier) : true
}

USE THIS>>>> cashout() function in script to manually cashout!
```

**Slide:**

> Use: https://www.youtube.com/watch?v=TkDPeuxEOUM <br />
```javascript
game = "slide"
nextbet = 0
target = 1.5

dobet = function(){

 if(id["identifier01"]){
    log("identifier01 won.")
 }

 if(id["identifier02"] == false){
    log("identifier02 lost.")
 }

 makebet(nextbet, target, "identifier01")
 makebet(nextbet, target, "identifier02")
 makebet(nextbet, target, "identifier03")
}
```

**hilo:**

```javascript
game = "hilo"
nextbet = 0
startcard = {"rank":"A","suit":"H"}
pattern = [5,5]
//selection = [4,5]

function dobet(){
    card = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"].sort(() => Math.random() - 0.5).slice(0, 1).toString();
    startcard = {"rank":card,"suit":"H"}
    //pattern = selection.sort(() => Math.random() - 0.5).slice(0, 1)
}

function round(){
  currentCardRank = currentBet.state.rounds.at(-1)?.card.rank || currentBet.state.startCard.rank;
  payoutMultiplier = currentBet.state.rounds.at(-1)?.payoutMultiplier || 0;
  skippedCards = currentBet.state.rounds.filter(round => round.guess === 'skip').length;

    if(currentBet.state.rounds.length < pattern.length){
	 guessing = pattern[currentBet.state.rounds.length]
    } else {
         return HILO_CASHOUT;
    }

    if (currentCardRank === "A" && guessing === 4) {
        return HILO_BET_LOW;
    }

    if (currentCardRank === "J" && guessing === 4) {
        return HILO_BET_HIGH;
    }

    if (currentCardRank === "Q" && guessing === 4) {
        return HILO_BET_HIGH;
    }

    if (currentCardRank === "K" && guessing === 4) {
        return HILO_BET_HIGH;
    }

    if (parseInt(currentCardRank) <= 10 && parseInt(currentCardRank) >= 7 && guessing === 4) {
        return HILO_BET_HIGH;
    }

    if (parseInt(currentCardRank) < 7 && guessing === 4) {
        return HILO_BET_LOW;
    }
   	 if (currentCardRank === "A" && guessing === 5) {
        return HILO_BET_HIGH;
    }

    if (currentCardRank === "J" && guessing === 5) {
        return HILO_BET_LOW;
    }

    if (currentCardRank === "Q" && guessing === 5) {
        return HILO_BET_LOW;
    }

    if (currentCardRank === "K" && guessing === 5) {
        return HILO_BET_LOW;
    }

    if (parseInt(currentCardRank) <= 10 && parseInt(currentCardRank) >= 7 && guessing === 5) {
        return HILO_BET_LOW;
    }

    if (parseInt(currentCardRank) < 7 && guessing === 5) {
        return HILO_BET_HIGH;
    }

    if(guessing === 2){
        return HILO_BET_EQUAL
    }

    return HILO_SKIP;
}
```
